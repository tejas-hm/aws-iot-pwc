const DynamoDB = require("aws-sdk/clients/dynamodb");
const documentClient = new DynamoDB.DocumentClient({ region: "us-east-1" });

const { sendResponse } = require("../utils");

const handler = async (event) => {
  const { email } = event.requestContext.authorizer.claims;

  let params = {
    TableName: "usersData",
    Key: { email }
  };

  const response = await documentClient.get(params).promise();
  const userData = response.Item;

  return sendResponse(200, {
    message: "Success",
    data: userData.devices
  });
};

module.exports = { handler };
