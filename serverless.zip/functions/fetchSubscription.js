const DynamoDB = require("aws-sdk/clients/dynamodb");
const documentClient = new DynamoDB.DocumentClient({ region: "us-east-1" });

const { sendResponse } = require("../utils");

const handler = async (event) => {
  const { email } = event.requestContext.authorizer.claims;

  const date = new Date();

  date.setHours(0);
  date.setMinutes(0);
  date.setSeconds(0);
  date.setMilliseconds(0);

  const currentDate = date.getTime();

  let params = {
    TableName: "plansData",
    Key: { planId }
  };

  const plan = await documentClient.get(params).promise();

  console.log("Plan", plan);

  params = {
    TableName: "subscriptions",
    Key: {
      email: email
    },
    UpdateExpression: "set planId = :planId, startDate = :startDate, endDate= :endDate",
    ExpressionAttributeValues: {
      ":planId": planId,
      ":startDate": startDate,
      ":endDate": endDate
    },
    ReturnValues: "UPDATED_NEW"
  };

  await documentClient.update(params).promise();

  return sendResponse(200, {
    message: `Plan Id ${planId} has been added to user ${email}`
  });
};

module.exports = { handler };
