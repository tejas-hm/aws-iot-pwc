const DynamoDB = require("aws-sdk/clients/dynamodb");
const documentClient = new DynamoDB.DocumentClient({ region: "us-east-1" });

const { sendResponse } = require("../utils");

const handler = async (event) => {
  const body = JSON.parse(event.body);
  const { deviceId } = body;
  const { email } = event.requestContext.authorizer.claims;

  //   let params = {
  //     TableName: "deviceData",
  //     Key: { deviceId }
  //   };

  //   const deviceObject = await documentClient.get(params).promise();
  //   const device = deviceObject.Item;

  //   const duration = plan.planDuration;
  //   const date = new Date();

  //   date.setHours(0);
  //   date.setMinutes(0);
  //   date.setSeconds(0);
  //   date.setMilliseconds(0);

  //   const startDate = date.getTime();
  //   date.setMonth(date.getMonth() + duration);
  //   const endDate = date.getTime();

  params = {
    TableName: "usersData",
    Key: {
      email: email
    },
    UpdateExpression: "SET devices.#deviceID = :deviceData",
    ExpressionAttributeNames: {
      "#deviceID": deviceId
    },
    ExpressionAttributeValues: {
      ":deviceData": { name: "Living Room AC", permission: "watch" }
    },
    ReturnValues: "UPDATED_NEW"
  };

  const a = await documentClient.update(params).promise();
  console.log(a);

  return sendResponse(200, {
    message: `Device id ${deviceId} has been added to user ${email}`
  });
};

module.exports = { handler };
